#include<stdio.h>
int main() {

	
	int count=0;
	int x;
	scanf("%d",&x);
	for(int i=1; i<=x; i=i+1) {
		if(x % i == 0) {
			count=count+1;
		}
	}
	if(count==2) {
		printf("prime no.");
	}else{
	    printf("not a prime no.");
	}
	return 0;
}
#include <stdio.h>

int main()
{
    int x=4;
    int i;
    for(i=0;i<x;i=i+1){
        int j;
        for(j=0;j<x-i-1 ;j=j+1){
            printf(" ");
        }
        for(j=0;j<i+1 ;j=j+1){
            if(j==0)
                printf("*");
            else
                printf(" ");
        }
        for(j=0;j<i;j=j+1){
            if(j==i-1)
                printf("*");
            else
                printf(" ");
        }
	printf("\n");
    }
    for(i=0;i<x;i=i+1){
        if(i==0)
            continue;
        int j;
        for(j=0;j<i;j=j+1){
            printf(" ");
        }
        for(j=0;j<x-i;j=j+1){
            if(j==0)
                printf("*");
            else
                printf(" ");
        }
        for(j=0; j<x-i-1 ;j=j+1){
            if(j==x-i-2)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
	return 0;
}

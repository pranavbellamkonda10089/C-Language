#include <stdio.h>

int main()
{
	int x,y;
	scanf("%d",&x);
label:
	scanf("%d",&y);
	int sum=x+y;
	int i;
	int count =0;
	for(i=1; i<=sum; i=i+1) {
		if(sum%i==0) {
			count=count+1;
		}
	}
	if(count==2) {
		printf("%d",sum);
	}
	else {
		printf("not prime, enter again");
		goto label;
	}


	return 0;
}

#include <stdio.h>

int main()
{
    int a=0;
    int b=0;
    int c=5;
    if(a++){
        printf("%d",c);
    }

    return 0;
}


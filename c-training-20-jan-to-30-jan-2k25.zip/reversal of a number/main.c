#include <stdio.h>
int main()
{
	int x;
	int rev=0;
	int a;
	scanf("%d",&x);
	while(x>0){
	    a=x%10;
	    rev=rev*10+a;
	    x=x/10;
	}
	printf("%d",rev);
	return 0;
}

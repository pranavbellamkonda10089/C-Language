//return gcd using functions
//take an integer from the user and chreck whether it is a perfect number or not
#include <stdio.h>
int gcd(int a,int b){
    int q1;
    if(a>b){
        q1=a;
    }else{
        q1=b;
    }
    int gcd;
    int i;
    for(i=q1;i>=1;i--){
        if(a%i==0&&b%i==0){
            gcd=i;
            break;
        }
    }
    return gcd;
    
}
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    int ans=gcd(x,y);
    printf("%d",ans);
    return 0;
}

#include <stdio.h>

int main()
{
    int z;
    scanf("%d",&z);
    int i=1;
    while(i<z){
        if(i*i==z){
            printf("perfect square");
            goto label;
        }
        i=i+1;
    }
    printf("not perfect square");
    label:
    return 0;
}
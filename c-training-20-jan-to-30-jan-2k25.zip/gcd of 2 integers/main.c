#include <stdio.h>

int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    int x;
    if(a<b){
        x=a;}
    else{
        x=b;}
    int gcd;
    int i;
    for(i=x;i>=1;i--){
        if(a%i==0&&b%i==0){
            gcd=i;
            break;
        }
    }
    printf("%d",gcd);
    return 0;
}

#include <stdio.h>

int main()
{
	int num=2546;
	int y=num;
	int a=num%10;
	num=num/10;
	int b=num%10;
	num=num/10;
	int c=num%10;
	num=num/10;
	int d=num%10;
	int i=0;
	while(i<10) {
		int x;
		scanf("%d",&x);
		int j=0;
		int count =0;
		while(j<4) {
			int p=x%10;
			if(j==0&&p==a) {
				count=count+10;
			} else if(j==0&&(p==b||p==c||p==d)) {
				count=count+2;
			}
			if(j==1&&p==b) {
				count=count+10;
			} else if(j==1&&(p==a||p==c||p==d)) {
				count=count+2;
			}
			if(j==2&&p==c) {
				count=count+10;
			} else if(j==2&&(p==a||p==b||p==d)) {
				count=count+2;
			}
			if(j==3&&p==d) {
				count=count+10;
			} else if(j==3&&(p==a||p==b||p==c)) {
				count=count+2;
			}
			x=x/10;
			j=j+1;

		}
		if(count==40) {
			printf("your guess is correct\n");
			break;
		} else {
			printf("try again and your score is %d\n",count);
		}
		i=i+1;
	}

	return 0;
}

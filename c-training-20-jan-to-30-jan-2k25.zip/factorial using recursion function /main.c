#include <stdio.h>
int fact(int n){
    if(n==1){
        return 1;
    }
    int fact1 =( n * fact(n-1));
    return fact1;
}
int main()
{
    int x;
    scanf("%d",&x);
    int ans=fact(x);
    printf("%d",ans);
    
    return 0;
}
#include <stdio.h>

int main()
{
    int a=5;
    int b=9;
    int c=0;
    if(a||b++ && c){
        printf("%d",b);
    }

    return 0;
}

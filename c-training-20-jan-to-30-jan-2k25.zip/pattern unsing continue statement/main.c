#include <stdio.h>

int main()
{
	int x=4;
	int i;
	for(i=0; i<x; i=i+1) {
		int j;
		for(j=0; j<i; j=j+1) {
			printf(" ");
		}
		for(j=0; j< x-i; j=j+1) {
			    printf("*");
			    
		}
		for(j=0; j<x-i-1 ;j=j+1){
		    printf("*");
		}
	printf("\n");
	}
	for(i=0; i<x; i=i+1) {
	    int j;
	    if(i==0){
		    continue;
		}
		for(j=0; j< x-i-1;j=j+1){
		    printf(" ");
		}

		for(j=0; j<i+1;j=j+1){
		    printf("*");
		}
		for(j=0;j<i;j=j+1){
		    printf("*");
		}
	printf("\n");
	}
	return 0;
}

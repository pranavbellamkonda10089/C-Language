#include <stdio.h>

int main()
{
    int x=20;
    int i;
    for(i=0;i<x;i=i+1){
        int j;
        for(j=0;j<x-i-1;j=j+1){
            printf(" ");
        }
        for(j=0;j<i+1;j++){
            printf("*");
        }
        for(j=0;j<i;j++){
            printf("*");
        }
    printf("\n");
    }
    int last=x*2-1;
    for(i=0;i<x-2;i++){
        int j;
        for(j=0;j<x-2;j++){
            printf("*");
        }
        int rem=last-(x-2 + x-2);
        for(j=0;j<rem;j++){
            printf(" ");
        }
        for(j=0;j<x-2;j++){
            printf("*");
        }
    printf("\n");
    }

    return 0;
}

#include <stdio.h>

int main()
{
    int x,y,z;
    scanf("%d%d%d",&x,&y,&z);
    
    int sum=x+y+z;
    if(sum%2!=0){
        goto label;}
    printf("%d\n",x);
    label:
    printf("%d\n",sum);

    return 0;
}

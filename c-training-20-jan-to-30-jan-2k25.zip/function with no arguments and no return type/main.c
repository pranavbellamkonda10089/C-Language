//write a program to create a function with the name as sum which should take
//two numbers input from the user and print their diffrence
#include <stdio.h>
void sum(){
    int a,b;
    scanf("%d%d",&a,&b);
    int c=a-b;
    printf("%d",c);
}
int main()
{
    sum();
    
    return 0;
}

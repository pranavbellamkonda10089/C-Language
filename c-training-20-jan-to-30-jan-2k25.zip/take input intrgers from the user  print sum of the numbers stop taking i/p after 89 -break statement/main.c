#include <stdio.h>

int main()
{
    int x;
    int sum=0;
    
    while(1){
        scanf("%d",&x);
        
        if(x==89){
            break;}
            
        sum=sum+x;
    }
    printf("%d",sum);
    return 0;
}

#include <stdio.h>

int main()
{
    int x;
    scanf("%d",&x);
    int fact=1;
    int i;
    for(i=1;i<=x;i=i+1){
        fact=fact*i;
    }
    printf("%d",fact);
    
    return 0;
}

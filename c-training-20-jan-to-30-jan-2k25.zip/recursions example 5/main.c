#include <stdio.h>
void help(int n)
{
  if(n<=2){
    return;  
  }  
  printf("%d",n-2);
  help(n-1);
  printf("%d",n-3);
  help(n-4);
}
int main()
{
    help(6);
    return 0;
}
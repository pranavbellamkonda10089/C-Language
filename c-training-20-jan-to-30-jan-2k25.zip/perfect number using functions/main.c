#include <stdio.h>
int perfect(int a){
    int i;
    int sum=0;
    for(i=1;i<a;i++){
        if(a%i==0){
        sum=sum+i;
        }
    }
    if(sum==a){
        return 1;
    }else{
    return 0;
    }
}
int main()
{
    int x;
    scanf("%d",&x);
    int ans=perfect(x);
    printf("%d",ans);
    return 0;
}

#include <stdio.h>

int main()
{
    int a=5;
    int *b=&a;
    printf("%ld",&a);
    printf("\n%ld",*b);

    return 0;
}

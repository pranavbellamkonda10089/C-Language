#include <stdio.h>

int main()
{
    int x;
    scanf("%d",&x);
    
    for(int i=0;i<x;i=i+1){
        int j;
        for(j=0;j<x;j=j+1){
            if(i==0||i==x-1||j==0||j==x-1)
                printf("*");
            else
                printf(" ");
        }
    printf("\n");
    }
    return 0;
}

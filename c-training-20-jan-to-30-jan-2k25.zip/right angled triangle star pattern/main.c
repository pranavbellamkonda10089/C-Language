#include <stdio.h>

int main()
{
    int i;
    int x;
    scanf("%d",&x);
    for(i=0;i<x;i=i+1){
        int j;
        for(j=0;j<i+1;j=j+1){
            printf("*");
        }
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
int main()
{
	int z;
	scanf("%d",&z);
	res=z&(z-1);
	if(res==0) {
		printf("True");
		goto label;
	}
	printf("false");
    label:
	return 0;
}
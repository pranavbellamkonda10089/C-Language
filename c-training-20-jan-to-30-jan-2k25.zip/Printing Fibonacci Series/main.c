#include <stdio.h>

int main()
{
    int x;
    scanf("%d",&x);
    int n1=0;
    printf("%d",n1);
    int n2=1;
    printf("%d",n2);
    int next;
    for(int i=1;i<x;i++){
        next=n1+n2;
        printf("%d",next);
        n1=n2;
        n2=next;
    }
    return 0;
}

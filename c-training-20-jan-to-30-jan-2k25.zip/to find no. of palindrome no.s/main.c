#include <stdio.h>
int main()
{
	int count=0;
	int i;
	for(i=0; i<5; i=i+1) {
	    
		int x;
		int y=x;
		int rev=0;
		scanf("%d",&x);
		while(x>0) {
			int a=x%10;
			rev=rev*10+a;
			x=x/10;
		}
		if(rev==y){
		    count=count+1;
		}
	}
	printf("%d",count);
	return 0;
}

#include <stdio.h>
int main()
{
	int x;
	int sum=0;
	int a;
	scanf("%d",&x);
	while(x>0){
	    a=x%10;
	    sum=sum+a;
	    x=x/10;
	}
	printf("%d",sum);
	return 0;
}

#include <stdio.h>
int sum(int a,int b){
    int res=a+b;
    return res;
}

int main()
{
    int x;
    int y;
    scanf("%d",&x);
    scanf("%d",&y);
    int ans=sum(x,y);
    printf("%d",ans);
    return 0;
}

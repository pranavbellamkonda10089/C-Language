#include <stdio.h>

int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    int x;
    if(a<b){
        x=a;
    }
    else{
        x=b;
    }
    int hcf;
    int i;
    for(i=x;i>=x;i--){
        if(a%i==0 && b%i==0){
            hcf=i;
            break;
        }
    }
    int lcm=(a*b)/hcf;
    printf("%d",lcm);
    return 0;
}

#include <stdio.h>

int main()
{
    int x;
    label:
    scanf("%d",&x);
    if(x%2==0){
        printf("even number");
    }
    else{
        printf("you hav entered the wrong number\n");
        goto label;
    }

    return 0;
}

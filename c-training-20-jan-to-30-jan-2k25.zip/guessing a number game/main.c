#include <stdio.h>

int main()
{
	int x=55;
	label:
	int i=0;

	while(i<10) {
		int a;
		scanf("%d",&a);
		if(x>a) {
			printf("number is less than expected number\n");
		} else if(x<a) {
			printf("number is greater than expected number\n");
		} else if(x==a) {
			printf("correct number\n");
			break;
		}
		i=i+1;
		if(i==10) {
			printf("your chances got over\n");
			printf("if want to try again press 1 or else 0\n");
			int q;
			scanf("%d",&q);
			switch(q){
			    case 0:printf("user dont want to play the game\n");
			           return 0;
			    case 1:goto label;
			}
		}
	}


	return 0;
}

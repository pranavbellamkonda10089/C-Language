//take an integer input from the user and create a function with the name as power 
//which should return 1 if the number is power of 2 and return 0 if the number is not 
//a power of 2
#include <stdio.h>
int power(int a){
    int res=a&a-1;
    if(res==0){
        return 1;
    }
    else{
        return 0;
    }
}
int main()
{  
    int x;
    scanf("%d",&x);
    int ans=power(x);
    printf("%d",ans);
    return 0;
}

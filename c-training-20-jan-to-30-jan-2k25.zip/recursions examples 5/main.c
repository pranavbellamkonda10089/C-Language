#include <stdio.h>
void help(int n) {
	if(n<=1) {
		return;
	}
	help(n-2);
	printf("%d",n);
	help(n-1);
	printf("%d",n-2);
	help(n-3);
}

int main()
{
	help(4);

	return 0;
}

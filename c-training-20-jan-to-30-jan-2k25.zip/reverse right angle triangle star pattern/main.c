#include <stdio.h>

int main()
{
	int x;
	int i;
	scanf("%d",&x);
	for(i=0; i<x; i=i+1) {
		int j;
		for(j=0; j<x-i-1; j=j+1) {
			printf(" ");
		}
		for(j=0; j<i+1; j=j+1) {
			printf("*");
		}
	printf("\n");
	}

	return 0;
}

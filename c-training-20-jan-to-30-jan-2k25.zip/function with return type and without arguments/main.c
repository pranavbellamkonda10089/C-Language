
#include <stdio.h>
int help(){
    int x,y;
    scanf("%d%d",&x,&y);
    int res=x+y;
    return res;
}

int main()
{
    int ans=help();
    printf("%d",ans);

    return 0;
}
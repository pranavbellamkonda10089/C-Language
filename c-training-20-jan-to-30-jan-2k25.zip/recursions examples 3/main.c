#include <stdio.h>
void help(int n) {
	if(n<=1) {
		return;
	}
	printf("%d",n);
	help(n-2);
	printf("%d",n-1);
	help(n-1);

}

int main()
{
	help(5);

	return 0;
}

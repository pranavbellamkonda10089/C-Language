#include <stdio.h>
void help(int n){
    if(n<=2){
        return;
    }
    printf("%d",n);
    help(n-2);
    printf("%d",n-2);
}
int main()
{
    help(5);

    return 0;
}
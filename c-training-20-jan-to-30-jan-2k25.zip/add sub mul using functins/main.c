#include <stdio.h>

int add(int a, int b) {
	int ans1=a+b;
	return ans1;
}
int sub(int a, int b) {
	int ans2=a-b;
	return ans2;
}
int mul(int a, int b) {
	int ans3=a*b;
	return ans3;
}
int main()
{
	int x,y;
	scanf("%d%d",&x,&y);
	int res1=add(x,y);
	int res2=sub(x,y);
	int res3=mul(x,y);
	printf("addition=%d\n",res1);
	printf("subtraction=%d\n",res2);
	printf("multiplication=%d\n",res3);
	return 0;
}

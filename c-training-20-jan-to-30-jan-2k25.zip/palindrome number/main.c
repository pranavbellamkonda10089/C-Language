#include <stdio.h>

int main()
{
    int x;
    label:
    scanf("%d",&x);
    int y=x;
    int rev=0;
    while(x>0){
        int a=x%10;
        rev=rev*10+a;
        x=x/10;
    }
    if(rev==y){
        printf("palindrome number\n");
    }
    else{
        printf("wrong number enter again\n");
        goto label;
    }
    return 0;
}

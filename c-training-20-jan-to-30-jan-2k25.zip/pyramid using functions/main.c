//triangle pattern
#include <stdio.h>
void triangle(int x){
    int i;
    for(i=0;i<x;i++){
        int j;
        for(j=0;j<x-i-1;j++){
            printf(" ");
        }
        for(j=0;j<i+1;j++){
            printf("*");
        }
        for(j=0;j<i;j++){
            printf("*");
        }
        printf("\n");
    }
}
int main()
{
    int x;
    printf("Enter number of rows:  ");
    scanf("%d",&x);
    triangle(x);

    return 0;
}

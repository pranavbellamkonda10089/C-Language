#include <stdio.h>
int fib(int x){
    if(x<=0){
        return 0;
    }
    if(x==1){
        return 0;
    }if(x==2){
        return 1;
    }
    int ans=fib(x-1)+fib(x-2);
    return ans;
}
int main()
{   
    int x;
    scanf("%d",&x);
    int a=fib(x);
    printf("%d",a);
    return 0;
}

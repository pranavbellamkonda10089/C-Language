#include <stdio.h>

int main()
{
    int x;
    label:
    scanf("%d",&x);
    int sum=0;
    int i;
    for(i=1;i<x;i=i+1){
        if(x%i==0){
            sum=sum+i;
        }
    }
    if(sum==x){
        printf("perfect number");
    }
    else{
        printf("not perfect, Please enter again\n");
        goto label;
    }

    return 0;
}

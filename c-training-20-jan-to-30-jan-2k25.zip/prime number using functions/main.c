//given an integer n using the concept of function check whether it is a prime 
//or not
#include <stdio.h>
int prime(int a){
    int i;
    int count=0;
    for(i=1;i<=a;i=i+1){
        if(a%i==0){
            count=count+1;
        }
    }
    if(count==2){
        return 1;
    }
    return 0;
}
int main()
{   
    int x;
    scanf("%d",&x);
    int ans=prime(x);
    printf("%d",ans);
    return 0;
}


#include <stdio.h>

int main()
{
    int x;
    scanf("%d",&x);
    int i;
    for(i=0;i<x;i=i+1){
        int j;
        for(j=0;j<i;j=j+1){
            printf(" ");
        }
        for(j=0; j<x; j=j+1){
            if(j==i||i==0)
                printf("*");
            else
                printf(" ");
        }  
        int k=x-i-1;
        for(j=0;j<k;j=j+1){
            if(j=k-1||i==0)
                printf("*");
            else
                printf(" ");
        }
    printf("\n");
    }
    return 0;
}
